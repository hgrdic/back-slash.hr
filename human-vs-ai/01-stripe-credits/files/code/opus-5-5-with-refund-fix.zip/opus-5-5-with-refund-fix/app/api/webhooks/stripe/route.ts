import type Stripe from "stripe";
import { fulfillCheckout, idOf, revokeCredits, stripe } from "@/lib/stripe";

export async function POST(req: Request) {
  const signature = req.headers.get("stripe-signature");
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!signature || !secret) {
    return new Response("Missing signature or webhook secret", { status: 400 });
  }

  let event: Stripe.Event;
  try {
    // Signature check needs the exact raw body.
    event = stripe().webhooks.constructEvent(await req.text(), signature, secret);
  } catch (err) {
    console.error("Webhook signature verification failed", err);
    return new Response("Invalid signature", { status: 400 });
  }

  if (
    event.type === "checkout.session.completed" ||
    event.type === "checkout.session.async_payment_succeeded"
  ) {
    fulfillCheckout(event.data.object);
  } else if (event.type === "charge.refunded") {
    const charge = event.data.object;
    const paymentIntentId = idOf(charge.payment_intent);
    if (paymentIntentId) await revokeCredits(paymentIntentId, charge.amount_refunded);
  } else if (event.type === "charge.dispute.created") {
    const paymentIntentId = idOf(event.data.object.payment_intent);
    if (paymentIntentId) await revokeCredits(paymentIntentId, "all");
  }

  return Response.json({ received: true });
}
