import "server-only";
import Stripe from "stripe";
import { db } from "./db";

// Prices live on the server only, the client just sends a pack id.
export const PACKS = {
  small: { credits: 10, amountCents: 500, label: "10 credits for $5" },
  large: { credits: 50, amountCents: 2000, label: "50 credits for $20" },
} as const;

export type PackId = keyof typeof PACKS;

export const isPackId = (value: unknown): value is PackId =>
  typeof value === "string" && Object.hasOwn(PACKS, value);

let client: Stripe | undefined;

export function stripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY is missing from .env");
  return (client ??= new Stripe(key));
}

/**
 * Adds credits for a paid Checkout Session. Safe to call more than once for
 * the same session (webhook and success page both call it): the payments
 * table primary key makes sure credits are only added the first time.
 */
export function fulfillCheckout(session: Stripe.Checkout.Session) {
  if (session.payment_status !== "paid") return false;

  const userId = Number(session.metadata?.userId);
  const packId = session.metadata?.packId;
  if (!Number.isInteger(userId) || !isPackId(packId)) return false;

  const pack = PACKS[packId];
  if (session.amount_total !== pack.amountCents || session.currency !== "usd") {
    console.error("Checkout amount mismatch, not crediting", session.id);
    return false;
  }

  const conn = db();
  return conn.transaction(() => {
    const inserted = conn
      .prepare(
        `INSERT OR IGNORE INTO payments
           (stripe_session_id, user_id, credits, amount_cents, payment_intent_id)
         VALUES (?, ?, ?, ?, ?)`,
      )
      .run(session.id, userId, pack.credits, pack.amountCents, idOf(session.payment_intent));
    if (inserted.changes === 0) return false; // already fulfilled
    conn.prepare("UPDATE users SET credits = credits + ? WHERE id = ?").run(
      pack.credits,
      userId,
    );
    return true;
  })();
}

export const idOf = (value: string | { id: string } | null) =>
  typeof value === "string" ? value : (value?.id ?? null);

/**
 * Finds the Checkout Session id we recorded for a payment intent. Payments
 * made before payment intents were stored (or a refund that arrives before
 * fulfillment) are looked up in Stripe, fulfilled if needed and backfilled.
 */
async function findPaymentSession(paymentIntentId: string) {
  const conn = db();
  const row = conn
    .prepare("SELECT stripe_session_id FROM payments WHERE payment_intent_id = ?")
    .get(paymentIntentId) as { stripe_session_id: string } | undefined;
  if (row) return row.stripe_session_id;

  const { data } = await stripe().checkout.sessions.list({
    payment_intent: paymentIntentId,
    limit: 1,
  });
  const session = data[0];
  if (!session) return null; // not a payment from this app

  fulfillCheckout(session);
  const updated = conn
    .prepare("UPDATE payments SET payment_intent_id = ? WHERE stripe_session_id = ?")
    .run(paymentIntentId, session.id);
  return updated.changes > 0 ? session.id : null;
}

/**
 * Takes credits back after a refund or chargeback. `reversedCents` is the
 * total amount reversed so far for the payment (Stripe sends running totals),
 * or "all" for a chargeback. Safe to call repeatedly and in any order: only
 * the difference from what was already taken back is removed.
 */
export async function revokeCredits(paymentIntentId: string, reversedCents: number | "all") {
  const sessionId = await findPaymentSession(paymentIntentId);
  if (!sessionId) return 0;

  const conn = db();
  return conn.transaction(() => {
    const payment = conn
      .prepare(
        `SELECT user_id, credits, amount_cents, credits_revoked
         FROM payments WHERE stripe_session_id = ?`,
      )
      .get(sessionId) as {
      user_id: number;
      credits: number;
      amount_cents: number;
      credits_revoked: number;
    };

    // Partial refunds take back a matching share of credits, rounded up.
    const target =
      reversedCents === "all"
        ? payment.credits
        : Math.min(
            payment.credits,
            Math.ceil((payment.credits * reversedCents) / payment.amount_cents),
          );
    const toRevoke = target - payment.credits_revoked;
    if (toRevoke <= 0) return 0;

    // Credits already spent can't be taken back, so the balance stops at zero.
    conn
      .prepare("UPDATE users SET credits = MAX(credits - ?, 0) WHERE id = ?")
      .run(toRevoke, payment.user_id);
    conn
      .prepare("UPDATE payments SET credits_revoked = ? WHERE stripe_session_id = ?")
      .run(target, sessionId);
    return toRevoke;
  })();
}
