import "server-only";
import Database from "better-sqlite3";
import path from "node:path";

const globalForDb = globalThis as unknown as { db?: Database.Database };

function open() {
  const db = new Database(path.join(process.cwd(), "app.db"));
  db.pragma("busy_timeout = 5000");
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      credits INTEGER NOT NULL DEFAULT 0 CHECK (credits >= 0),
      created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS payments (
      stripe_session_id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      credits INTEGER NOT NULL,
      amount_cents INTEGER NOT NULL,
      created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
  `);

  // Columns added after the first release. CREATE TABLE IF NOT EXISTS leaves
  // existing databases alone, so add them here when they're missing.
  const paymentColumns = (
    db.prepare("PRAGMA table_info(payments)").all() as { name: string }[]
  ).map((c) => c.name);
  if (!paymentColumns.includes("payment_intent_id")) {
    db.exec("ALTER TABLE payments ADD COLUMN payment_intent_id TEXT");
  }
  if (!paymentColumns.includes("credits_revoked")) {
    // Credits taken back after a refund or chargeback.
    db.exec("ALTER TABLE payments ADD COLUMN credits_revoked INTEGER NOT NULL DEFAULT 0");
  }
  db.exec(
    "CREATE INDEX IF NOT EXISTS payments_payment_intent_id ON payments (payment_intent_id)",
  );
  return db;
}

// Opened on first use (not at import, so build workers don't touch it) and
// reused across hot reloads in dev.
export const db = () => (globalForDb.db ??= open());

export type User = { id: number; email: string; credits: number };
