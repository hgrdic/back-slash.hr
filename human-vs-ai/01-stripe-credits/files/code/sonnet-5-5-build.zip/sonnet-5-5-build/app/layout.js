export const metadata = { title: "Quote Credits" };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body
        style={{
          fontFamily: "system-ui, sans-serif",
          maxWidth: 520,
          margin: "40px auto",
          padding: "0 16px",
          lineHeight: 1.5,
        }}
      >
        {children}
      </body>
    </html>
  );
}
