"use client";
import { useState } from "react";

export default function AuthForm({ mode }) {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const signup = mode === "signup";

  async function onSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(e.target);
    const res = await fetch(`/api/${mode}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: form.get("email"), password: form.get("password") }),
    });
    if (res.ok) {
      window.location.href = "/dashboard";
    } else {
      setError((await res.json()).error || "Something went wrong");
      setBusy(false);
    }
  }

  return (
    <>
      <h1>{signup ? "Sign up" : "Log in"}</h1>
      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12 }}>
        <input name="email" type="email" placeholder="Email" required />
        <input name="password" type="password" placeholder="Password (8+ characters)" required minLength={8} />
        <button disabled={busy}>{signup ? "Create account" : "Log in"}</button>
        {error && <p style={{ color: "crimson" }}>{error}</p>}
      </form>
      <p>
        {signup ? (
          <>Have an account? <a href="/login">Log in</a></>
        ) : (
          <>No account? <a href="/signup">Sign up</a></>
        )}
      </p>
    </>
  );
}
