import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import { stripe, fulfillSession } from "@/lib/stripe";
import Dashboard from "./Dashboard";

export const dynamic = "force-dynamic";

export default async function Page({ searchParams }) {
  let user = await getUser();
  if (!user) redirect("/login");

  // Returning from Stripe: credit the purchase right away (idempotent, so it's
  // fine if the webhook also fires). Works even without the webhook running.
  const { session_id } = await searchParams;
  if (session_id) {
    try {
      const session = await stripe.checkout.sessions.retrieve(session_id);
      if (session.metadata?.userId === String(user.id) && fulfillSession(session)) {
        user = await getUser();
      }
    } catch {}
  }

  return <Dashboard email={user.email} initialCredits={user.credits} justPaid={!!session_id} />;
}
