"use client";
import { useState } from "react";

export default function Dashboard({ email, initialCredits, justPaid }) {
  const [credits, setCredits] = useState(initialCredits);
  const [quote, setQuote] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function generate() {
    setBusy(true);
    setError("");
    const res = await fetch("/api/generate", { method: "POST" });
    const data = await res.json();
    if (res.ok) {
      setQuote(data.quote);
      setCredits(data.credits);
    } else {
      setError(data.error);
    }
    setBusy(false);
  }

  async function buy(packId) {
    setError("");
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ packId }),
    });
    const data = await res.json();
    if (res.ok) window.location.href = data.url;
    else setError(data.error);
  }

  async function logout() {
    await fetch("/api/logout", { method: "POST" });
    window.location.href = "/login";
  }

  return (
    <>
      <p>
        {email} · <a href="#" onClick={(e) => { e.preventDefault(); logout(); }}>Log out</a>
      </p>
      <h1>Credits: {credits}</h1>
      {justPaid && <p style={{ color: "green" }}>Thanks! Your payment was received.</p>}

      <button onClick={generate} disabled={busy || credits < 1}>Generate (1 credit)</button>
      {quote && <blockquote style={{ fontSize: 20 }}>{quote}</blockquote>}
      {error && <p style={{ color: "crimson" }}>{error}</p>}

      <h2>Buy credits</h2>
      <button onClick={() => buy("small")}>10 credits for $5</button>{" "}
      <button onClick={() => buy("large")}>50 credits for $20</button>
    </>
  );
}
