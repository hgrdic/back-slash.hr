import { stripe, fulfillSession } from "@/lib/stripe";

export async function POST(req) {
  const body = await req.text();
  let event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      req.headers.get("stripe-signature"),
      process.env.STRIPE_WEBHOOK_SECRET || ""
    );
  } catch {
    return new Response("Bad signature", { status: 400 });
  }

  if (
    event.type === "checkout.session.completed" ||
    event.type === "checkout.session.async_payment_succeeded"
  ) {
    fulfillSession(event.data.object);
  }
  return new Response("ok");
}
