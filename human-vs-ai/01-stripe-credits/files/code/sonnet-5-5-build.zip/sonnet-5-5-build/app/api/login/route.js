import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

export async function POST(req) {
  const { email, password } = await req.json().catch(() => ({}));
  const user = db
    .prepare("SELECT id, password_hash FROM users WHERE email = ?")
    .get(String(email || "").trim().toLowerCase());
  const ok = user && (await bcrypt.compare(String(password || ""), user.password_hash));
  if (!ok) return Response.json({ error: "Invalid email or password" }, { status: 401 });
  await createSession(user.id);
  return Response.json({ ok: true });
}
