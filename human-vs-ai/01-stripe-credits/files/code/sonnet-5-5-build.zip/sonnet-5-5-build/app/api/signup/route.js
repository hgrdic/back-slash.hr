import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createSession } from "@/lib/auth";

export async function POST(req) {
  const { email, password } = await req.json().catch(() => ({}));
  const e = String(email || "").trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(e)) return Response.json({ error: "Enter a valid email" }, { status: 400 });
  if (String(password || "").length < 8)
    return Response.json({ error: "Password must be at least 8 characters" }, { status: 400 });

  const hash = await bcrypt.hash(password, 10);
  try {
    const r = db.prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)").run(e, hash);
    await createSession(Number(r.lastInsertRowid));
    return Response.json({ ok: true });
  } catch (err) {
    if (String(err.code).startsWith("SQLITE_CONSTRAINT"))
      return Response.json({ error: "Email already registered" }, { status: 409 });
    throw err;
  }
}
