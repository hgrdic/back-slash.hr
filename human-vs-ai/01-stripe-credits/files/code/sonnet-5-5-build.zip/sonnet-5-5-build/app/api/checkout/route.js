import { getUser } from "@/lib/auth";
import { stripe, PACKS } from "@/lib/stripe";

export async function POST(req) {
  const user = await getUser();
  if (!user) return Response.json({ error: "Not logged in" }, { status: 401 });

  const { packId } = await req.json().catch(() => ({}));
  const pack = PACKS[packId];
  if (!pack) return Response.json({ error: "Unknown pack" }, { status: 400 });

  const base = process.env.APP_URL || "http://localhost:3000";
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: "usd",
          unit_amount: pack.cents,
          product_data: { name: pack.label },
        },
      },
    ],
    metadata: { userId: String(user.id), packId },
    success_url: `${base}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${base}/dashboard`,
  });
  return Response.json({ url: session.url });
}
