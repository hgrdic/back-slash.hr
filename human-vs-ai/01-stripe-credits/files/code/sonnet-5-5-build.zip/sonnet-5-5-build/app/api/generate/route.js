import { getUser } from "@/lib/auth";
import { db } from "@/lib/db";

const QUOTES = [
  "The only way to do great work is to love what you do. — Steve Jobs",
  "It always seems impossible until it's done. — Nelson Mandela",
  "Believe you can and you're halfway there. — Theodore Roosevelt",
  "Do what you can, with what you have, where you are. — Theodore Roosevelt",
  "The future depends on what you do today. — Mahatma Gandhi",
  "You miss 100% of the shots you don't take. — Wayne Gretzky",
  "Success is not final, failure is not fatal: it is the courage to continue that counts. — Winston Churchill",
  "Start where you are. Use what you have. Do what you can. — Arthur Ashe",
  "Whether you think you can or you think you can't, you're right. — Henry Ford",
  "The best time to plant a tree was 20 years ago. The second best time is now. — Chinese proverb",
];

export async function POST() {
  const user = await getUser();
  if (!user) return Response.json({ error: "Not logged in" }, { status: 401 });

  // Atomic: only deducts if the balance is still positive.
  const r = db.prepare("UPDATE users SET credits = credits - 1 WHERE id = ? AND credits > 0").run(user.id);
  if (r.changes === 0) return Response.json({ error: "No credits left. Buy more below." }, { status: 402 });

  const { credits } = db.prepare("SELECT credits FROM users WHERE id = ?").get(user.id);
  const quote = QUOTES[Math.floor(Math.random() * QUOTES.length)];
  return Response.json({ quote, credits });
}
