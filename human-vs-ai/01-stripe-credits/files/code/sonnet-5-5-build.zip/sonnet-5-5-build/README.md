# Quote Credits

Next.js + SQLite + Stripe Checkout. Sign up, buy credits, spend 1 credit per random motivational quote.

## Run it

1. `npm install`
2. Edit `.env` and set `STRIPE_SECRET_KEY` to your Stripe test secret key (https://dashboard.stripe.com/test/apikeys).
3. `npm run dev`, then open http://localhost:3000

The SQLite database (`data.db`) is created automatically on first run.

## Payments

Credits are added in two places, and each payment is only ever counted once:

- When Stripe sends you back to the dashboard after paying (works with no extra setup).
- Via the webhook at `/api/webhook` (covers users who close the tab before returning). To test it locally:

  ```
  stripe listen --forward-to localhost:3000/api/webhook
  ```

  Copy the `whsec_...` it prints into `STRIPE_WEBHOOK_SECRET` in `.env` and restart. In production, add a webhook endpoint in the Stripe dashboard for `checkout.session.completed`.

Test card: `4242 4242 4242 4242`, any future expiry, any CVC.
