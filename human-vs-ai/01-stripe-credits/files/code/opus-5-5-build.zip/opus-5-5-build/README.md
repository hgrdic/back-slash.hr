# Daily Motivation

Small Next.js app: sign up, buy credits with Stripe Checkout (10 for $5 or 50 for $20), and spend 1 credit per motivational quote. Data lives in a local SQLite file (`app.db`, created automatically on first request).

## Run it

1. Install dependencies:

   ```bash
   npm install
   ```

2. Open `.env` (if it's missing, run `cp .env.example .env`) and put your **test mode** secret key (`sk_test_...`) from https://dashboard.stripe.com/test/apikeys into `STRIPE_SECRET_KEY`.

3. (Recommended) Forward Stripe webhooks to your machine with the [Stripe CLI](https://docs.stripe.com/stripe-cli):

   ```bash
   brew install stripe/stripe-cli/stripe
   stripe login
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   ```

   Copy the `whsec_...` value it prints into `STRIPE_WEBHOOK_SECRET` in `.env`, and leave the command running.

   Without this step purchases still work locally: when Stripe redirects back to the dashboard, the app verifies the Checkout Session with Stripe and adds the credits. The webhook covers the case where the user closes the tab before the redirect.

4. Start the app:

   ```bash
   npm run dev
   ```

   Open http://localhost:3000, sign up, and buy a pack with the test card `4242 4242 4242 4242` (any future expiry, any CVC, any ZIP).

## How it works

* `lib/db.ts` sets up SQLite tables for users, sessions and payments.
* `lib/auth.ts` handles login sessions with a random token in an httpOnly cookie. Passwords are hashed with bcrypt.
* `app/actions.ts` contains the server actions for sign up, log in, buying credits and generating a quote. The credit is taken with a single conditional `UPDATE`, so the balance can never go below zero.
* `lib/stripe.ts` defines the credit packs (prices are set on the server only) and `fulfillCheckout`, which adds credits once per Checkout Session no matter how many times it is called.
* `app/api/webhooks/stripe/route.ts` verifies the Stripe signature and calls `fulfillCheckout`.

To start over, stop the server and delete `app.db*`.

## Going live

Use live keys, set `APP_URL` to your real domain, and add a webhook endpoint in the Stripe dashboard pointing to `https://your-domain/api/webhooks/stripe` for `checkout.session.completed` and `checkout.session.async_payment_succeeded`. SQLite needs a persistent disk, so serverless hosts like Vercel won't keep your data; use a VPS or something like Fly.io or Railway with a volume.
