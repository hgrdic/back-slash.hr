import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Daily Motivation",
  description: "Spend credits on motivational quotes",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
