"use client";

import Link from "next/link";
import { useActionState } from "react";
import { login, signup } from "./actions";

export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const [state, action, pending] = useActionState(mode === "login" ? login : signup, undefined);
  const isLogin = mode === "login";

  return (
    <main className="card narrow">
      <h1>{isLogin ? "Log in" : "Create an account"}</h1>
      <form action={action} className="stack">
        <label>
          Email
          <input name="email" type="email" required autoComplete="email" />
        </label>
        <label>
          Password
          <input
            name="password"
            type="password"
            required
            minLength={isLogin ? undefined : 8}
            autoComplete={isLogin ? "current-password" : "new-password"}
          />
        </label>
        {state?.error && <p className="error">{state.error}</p>}
        <button disabled={pending}>{pending ? "Please wait..." : isLogin ? "Log in" : "Sign up"}</button>
      </form>
      <p className="muted">
        {isLogin ? (
          <>No account yet? <Link href="/signup">Sign up</Link></>
        ) : (
          <>Already have an account? <Link href="/login">Log in</Link></>
        )}
      </p>
    </main>
  );
}
