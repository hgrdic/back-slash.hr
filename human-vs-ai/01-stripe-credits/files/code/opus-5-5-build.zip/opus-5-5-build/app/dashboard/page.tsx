import { Suspense } from "react";
import { requireUser } from "@/lib/auth";
import { PACKS, fulfillCheckout, stripe, type PackId } from "@/lib/stripe";
import { buyCredits, logout } from "../actions";
import { Generator } from "./generator";

export default function DashboardPage({ searchParams }: PageProps<"/dashboard">) {
  return (
    <main className="card">
      <Suspense fallback={<p className="muted">Loading...</p>}>
        <Dashboard searchParams={searchParams} />
      </Suspense>
    </main>
  );
}

async function Dashboard({ searchParams }: Pick<PageProps<"/dashboard">, "searchParams">) {
  let user = await requireUser();
  const { session_id, canceled } = await searchParams;

  // Returning from Stripe Checkout. The webhook also adds credits, this just
  // makes the balance correct right away (and works without the Stripe CLI).
  let notice: string | null = null;
  if (typeof session_id === "string") {
    try {
      const session = await stripe().checkout.sessions.retrieve(session_id);
      if (session.metadata?.userId === String(user.id)) {
        fulfillCheckout(session);
        notice =
          session.payment_status === "paid"
            ? "Payment received, your credits were added."
            : "Payment is processing, credits will appear once it completes.";
        user = await requireUser();
      }
    } catch (err) {
      console.error("Could not verify checkout session", err);
    }
  }

  return (
    <>
      <header className="row spread">
        <h1>Dashboard</h1>
        <form action={logout}>
          <button className="secondary">Log out</button>
        </form>
      </header>
      <p className="muted">Logged in as {user.email}</p>
      {notice && <p className="success">{notice}</p>}
      {canceled && <p className="muted">Checkout canceled, no charge was made.</p>}

      <Generator key={user.credits} initialCredits={user.credits} />

      <section className="stack">
        <h2>Buy credits</h2>
        <div className="row">
          {(Object.keys(PACKS) as PackId[]).map((id) => (
            <form key={id} action={buyCredits}>
              <input type="hidden" name="pack" value={id} />
              <button>{PACKS[id].label}</button>
            </form>
          ))}
        </div>
      </section>
    </>
  );
}
