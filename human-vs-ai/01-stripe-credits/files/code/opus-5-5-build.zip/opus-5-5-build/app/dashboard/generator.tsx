"use client";

import { useActionState } from "react";
import { generateQuote, type GenerateState } from "../actions";

export function Generator({ initialCredits }: { initialCredits: number }) {
  const [state, action, pending] = useActionState<GenerateState>(generateQuote, undefined);
  const credits = state?.credits ?? initialCredits;

  return (
    <section className="stack">
      <p className="balance">
        Credits: <strong>{credits}</strong>
      </p>
      <form action={action}>
        <button disabled={pending || credits < 1}>
          {pending ? "Generating..." : "Generate (1 credit)"}
        </button>
      </form>
      {state?.error && <p className="error">{state.error}</p>}
      {state?.quote && (
        <blockquote>
          <p>&ldquo;{state.quote.text}&rdquo;</p>
          <footer>{state.quote.author}</footer>
        </blockquote>
      )}
    </section>
  );
}
