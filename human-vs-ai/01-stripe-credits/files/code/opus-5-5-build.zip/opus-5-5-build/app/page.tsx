import Link from "next/link";

export default function Home() {
  return (
    <main className="card narrow">
      <h1>Daily Motivation</h1>
      <p>Buy credits, click Generate, get a motivational quote. One credit per quote.</p>
      <div className="row">
        <Link className="button" href="/signup">Sign up</Link>
        <Link className="button secondary" href="/login">Log in</Link>
      </div>
    </main>
  );
}
