"use server";

import bcrypt from "bcryptjs";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { createSession, destroySession, getUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { randomQuote } from "@/lib/quotes";
import { PACKS, isPackId, stripe } from "@/lib/stripe";

export type FormState = { error?: string } | undefined;

function readCredentials(formData: FormData) {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  return { email, password };
}

export async function signup(_: FormState, formData: FormData): Promise<FormState> {
  const { email, password } = readCredentials(formData);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Enter a valid email." };
  if (password.length < 8) return { error: "Password must be at least 8 characters." };

  const passwordHash = await bcrypt.hash(password, 10);
  let userId: number;
  try {
    const result = db()
      .prepare("INSERT INTO users (email, password_hash) VALUES (?, ?)")
      .run(email, passwordHash);
    userId = Number(result.lastInsertRowid);
  } catch (err) {
    if ((err as { code?: string }).code === "SQLITE_CONSTRAINT_UNIQUE") {
      return { error: "An account with that email already exists." };
    }
    throw err;
  }

  await createSession(userId);
  redirect("/dashboard");
}

export async function login(_: FormState, formData: FormData): Promise<FormState> {
  const { email, password } = readCredentials(formData);
  const row = db()
    .prepare("SELECT id, password_hash FROM users WHERE email = ?")
    .get(email) as { id: number; password_hash: string } | undefined;

  if (!row || !(await bcrypt.compare(password, row.password_hash))) {
    return { error: "Wrong email or password." };
  }

  await createSession(row.id);
  redirect("/dashboard");
}

export async function logout() {
  await destroySession();
  redirect("/login");
}

export async function buyCredits(formData: FormData) {
  const user = await getUser();
  if (!user) redirect("/login");

  const packId = formData.get("pack");
  if (!isPackId(packId)) throw new Error("Unknown credit pack");
  const pack = PACKS[packId];

  const h = await headers();
  const origin =
    process.env.APP_URL ?? `${h.get("x-forwarded-proto") ?? "http"}://${h.get("host")}`;

  const session = await stripe().checkout.sessions.create({
    mode: "payment",
    customer_email: user.email,
    client_reference_id: String(user.id),
    metadata: { userId: String(user.id), packId },
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: "usd",
          unit_amount: pack.amountCents,
          product_data: { name: `${pack.credits} credits` },
        },
      },
    ],
    success_url: `${origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/dashboard?canceled=1`,
  });

  redirect(session.url!);
}

export type GenerateState =
  | { quote?: { text: string; author: string }; credits?: number; error?: string }
  | undefined;

export async function generateQuote(): Promise<GenerateState> {
  const user = await getUser();
  if (!user) redirect("/login");

  // Atomic check and decrement, so double clicks can never go below zero.
  const result = db()
    .prepare("UPDATE users SET credits = credits - 1 WHERE id = ? AND credits >= 1")
    .run(user.id);
  if (result.changes === 0) {
    return { error: "You're out of credits. Buy more below.", credits: 0 };
  }

  const { credits } = db()
    .prepare("SELECT credits FROM users WHERE id = ?")
    .get(user.id) as { credits: number };
  return { quote: randomQuote(), credits };
}
