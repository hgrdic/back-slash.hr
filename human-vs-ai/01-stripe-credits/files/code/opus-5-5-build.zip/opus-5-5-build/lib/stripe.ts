import "server-only";
import Stripe from "stripe";
import { db } from "./db";

// Prices live on the server only, the client just sends a pack id.
export const PACKS = {
  small: { credits: 10, amountCents: 500, label: "10 credits for $5" },
  large: { credits: 50, amountCents: 2000, label: "50 credits for $20" },
} as const;

export type PackId = keyof typeof PACKS;

export const isPackId = (value: unknown): value is PackId =>
  typeof value === "string" && Object.hasOwn(PACKS, value);

let client: Stripe | undefined;

export function stripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY is missing from .env");
  return (client ??= new Stripe(key));
}

/**
 * Adds credits for a paid Checkout Session. Safe to call more than once for
 * the same session (webhook and success page both call it): the payments
 * table primary key makes sure credits are only added the first time.
 */
export function fulfillCheckout(session: Stripe.Checkout.Session) {
  if (session.payment_status !== "paid") return false;

  const userId = Number(session.metadata?.userId);
  const packId = session.metadata?.packId;
  if (!Number.isInteger(userId) || !isPackId(packId)) return false;

  const pack = PACKS[packId];
  if (session.amount_total !== pack.amountCents || session.currency !== "usd") {
    console.error("Checkout amount mismatch, not crediting", session.id);
    return false;
  }

  const conn = db();
  return conn.transaction(() => {
    const inserted = conn
      .prepare(
        `INSERT OR IGNORE INTO payments (stripe_session_id, user_id, credits, amount_cents)
         VALUES (?, ?, ?, ?)`,
      )
      .run(session.id, userId, pack.credits, pack.amountCents);
    if (inserted.changes === 0) return false; // already fulfilled
    conn.prepare("UPDATE users SET credits = credits + ? WHERE id = ?").run(
      pack.credits,
      userId,
    );
    return true;
  })();
}
