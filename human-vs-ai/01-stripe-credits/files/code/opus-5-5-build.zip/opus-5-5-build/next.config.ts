import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  cacheComponents: true,
  partialPrefetching: true,
  // Native module, load it from node_modules at runtime instead of bundling.
  serverExternalPackages: ["better-sqlite3"],
};

export default nextConfig;
