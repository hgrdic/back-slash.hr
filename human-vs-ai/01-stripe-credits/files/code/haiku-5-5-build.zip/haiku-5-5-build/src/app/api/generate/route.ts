import { getCurrentUser } from '@/lib/auth';
import { spendCredit } from '@/lib/credits';
import { randomQuote } from '@/lib/quotes';

export async function POST() {
  const user = await getCurrentUser();
  if (!user) {
    return Response.json({ error: 'Not signed in' }, { status: 401 });
  }

  const remaining = spendCredit(user.id);
  if (remaining === null) {
    return Response.json({ error: 'You are out of credits. Buy more to continue.' }, { status: 402 });
  }

  return Response.json({ quote: randomQuote(), credits: remaining });
}
