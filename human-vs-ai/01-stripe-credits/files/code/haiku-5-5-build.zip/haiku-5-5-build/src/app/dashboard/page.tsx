import { redirect } from 'next/navigation';
import { buyCredits, logout } from '../actions';
import { getCurrentUser } from '@/lib/auth';
import { PACKS } from '@/lib/packs';
import GenerateButton from './GenerateButton';

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; canceled?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect('/login');

  const { error, canceled } = await searchParams;

  return (
    <>
      <div className="card">
        <div className="row">
          <div>
            <h1>Dashboard</h1>
            <div className="muted">{user.email}</div>
          </div>
          <form action={logout}>
            <button type="submit" className="secondary">
              Log out
            </button>
          </form>
        </div>
      </div>

      {error && <div className="error">{error}</div>}
      {canceled && <div className="muted">Checkout was canceled. No charge was made.</div>}

      <div className="card">
        <h2>Your balance</h2>
        <div className="balance" data-testid="balance">
          {user.credits}
        </div>
        <div className="muted">Each quote costs 1 credit.</div>
      </div>

      <div className="card">
        <h2>Buy credits</h2>
        <div className="packs">
          {PACKS.map((pack) => (
            <form key={pack.id} action={buyCredits}>
              <input type="hidden" name="packId" value={pack.id} />
              <button type="submit">
                {pack.label} for ${(pack.priceCents / 100).toFixed(0)}
              </button>
            </form>
          ))}
        </div>
      </div>

      <div className="card">
        <h2>Motivation</h2>
        <GenerateButton initialCredits={user.credits} />
      </div>
    </>
  );
}
