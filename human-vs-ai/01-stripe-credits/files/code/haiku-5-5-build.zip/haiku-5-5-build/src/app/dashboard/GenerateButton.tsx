'use client';

import { useState } from 'react';

export default function GenerateButton({ initialCredits }: { initialCredits: number }) {
  const [credits, setCredits] = useState(initialCredits);
  const [quote, setQuote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function generate() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch('/api/generate', { method: 'POST' });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Something went wrong.');
        return;
      }
      setQuote(data.quote);
      setCredits(data.credits);
    } catch {
      setError('Network error. Try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {error && <div className="error">{error}</div>}
      <div className="quote">{quote ?? 'Click Generate to get a quote.'}</div>
      <div className="row">
        <button type="button" onClick={generate} disabled={busy || credits < 1}>
          {busy ? 'Generating...' : 'Generate (1 credit)'}
        </button>
        <span className="muted" data-testid="balance-inline">
          {credits} credit{credits === 1 ? '' : 's'} left
        </span>
      </div>
    </>
  );
}
