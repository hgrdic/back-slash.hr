import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { fulfillPaidSession } from '@/lib/credits';
import { getStripe } from '@/lib/stripe';

export default async function CheckoutSuccessPage({
  searchParams,
}: {
  searchParams: Promise<{ session_id?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect('/login');

  const { session_id: sessionId } = await searchParams;
  if (!sessionId) redirect('/dashboard');

  // The webhook is the main path. This is a fallback so credits show up
  // right away, and it works without `stripe listen` during local dev.
  let message: string;
  try {
    const session = await getStripe().checkout.sessions.retrieve(sessionId);
    if (session.metadata?.userId !== String(user.id)) {
      message = 'This checkout session does not belong to your account.';
    } else if (session.payment_status !== 'paid') {
      message = 'Payment is not complete yet. Credits will be added once it clears.';
    } else {
      fulfillPaidSession(session);
      message = 'Payment received. Your credits have been added.';
    }
  } catch (err) {
    console.error(err);
    message = 'We could not confirm your payment just now. Refresh in a moment, and check the webhook logs if credits do not appear.';
  }

  const fresh = await getCurrentUser();

  return (
    <div className="card">
      <h1>Thanks for your purchase</h1>
      <div className={message.startsWith('Payment received') ? 'notice' : 'error'}>{message}</div>
      <p>
        Current balance: <strong>{fresh?.credits ?? user.credits}</strong> credits
      </p>
      <Link href="/dashboard" className="button">
        Back to dashboard
      </Link>
    </div>
  );
}
