'use server';

import { redirect } from 'next/navigation';
import {
  createUser,
  endSession,
  findUserByEmail,
  getCurrentUser,
  startSession,
  verifyPassword,
} from '@/lib/auth';
import { getStripe } from '@/lib/stripe';
import { getPack } from '@/lib/packs';

function fail(page: string, message: string): never {
  redirect(`${page}?${new URLSearchParams({ error: message })}`);
}

export async function signup(formData: FormData) {
  const email = String(formData.get('email') ?? '').trim().toLowerCase();
  const password = String(formData.get('password') ?? '');

  if (!email.includes('@')) fail('/signup', 'Enter a valid email address.');
  if (password.length < 8) fail('/signup', 'Password must be at least 8 characters.');
  if (findUserByEmail(email)) fail('/signup', 'An account with that email already exists.');

  const userId = await createUser(email, password);
  await startSession(userId);
  redirect('/dashboard');
}

export async function login(formData: FormData) {
  const email = String(formData.get('email') ?? '').trim().toLowerCase();
  const password = String(formData.get('password') ?? '');

  const user = findUserByEmail(email);
  const ok = user ? await verifyPassword(password, user.password_hash) : false;
  if (!user || !ok) fail('/login', 'Invalid email or password.');

  await startSession(user.id);
  redirect('/dashboard');
}

export async function logout() {
  await endSession();
  redirect('/login');
}

export async function buyCredits(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect('/login');

  // The client only sends a pack id. Price and credits come from the server.
  const pack = getPack(String(formData.get('packId') ?? ''));
  if (!pack) fail('/dashboard', 'Unknown credit pack.');

  const appUrl = process.env.APP_URL ?? 'http://localhost:3000';
  const session = await getStripe().checkout.sessions.create({
    mode: 'payment',
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: 'usd',
          unit_amount: pack.priceCents,
          product_data: { name: pack.label },
        },
      },
    ],
    client_reference_id: String(user.id),
    metadata: { userId: String(user.id), packId: pack.id },
    success_url: `${appUrl}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${appUrl}/dashboard?canceled=1`,
  });

  if (!session.url) throw new Error('Stripe did not return a Checkout URL');
  redirect(session.url);
}
