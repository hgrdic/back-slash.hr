import type Stripe from 'stripe';
import { fulfillPaidSession } from '@/lib/credits';
import { getStripe } from '@/lib/stripe';

export async function POST(req: Request) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) {
    return Response.json({ error: 'STRIPE_WEBHOOK_SECRET is not set' }, { status: 500 });
  }

  // Stripe signs the raw body, so read it as text and don't parse it first.
  const body = await req.text();
  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return Response.json({ error: 'Missing signature' }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(body, signature, secret);
  } catch {
    return Response.json({ error: 'Invalid signature' }, { status: 400 });
  }

  if (
    event.type === 'checkout.session.completed' ||
    event.type === 'checkout.session.async_payment_succeeded'
  ) {
    fulfillPaidSession(event.data.object as Stripe.Checkout.Session);
  }

  return Response.json({ received: true });
}
