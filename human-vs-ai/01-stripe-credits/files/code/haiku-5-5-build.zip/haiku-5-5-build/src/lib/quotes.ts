const QUOTES = [
  'Small steps every day add up to big results.',
  'You do not have to be perfect to be amazing.',
  'The best time to start was yesterday. The next best time is now.',
  'Your only limit is the one you set for yourself.',
  'Progress, not perfection.',
  'Hard work beats talent when talent does not work hard.',
  'Every expert was once a beginner.',
  'Doubt kills more dreams than failure ever will.',
  'Make today the day you prove yourself right.',
  'Courage is showing up even when you are scared.',
  'The journey of a thousand miles begins with a single step.',
  'Discipline is choosing what you want most over what you want now.',
  'Do not wait for the perfect moment. Take the moment and make it perfect.',
  'What you do today can improve all your tomorrows.',
  'Fall seven times, stand up eight.',
  'Believe in yourself, and the rest will follow.',
  'Quitting is a choice you do not have to make today.',
  'Success is the sum of small efforts repeated day in and day out.',
  'You are stronger than you think and braver than you feel.',
  'Dream big, start small, act now.',
];

export function randomQuote(): string {
  return QUOTES[Math.floor(Math.random() * QUOTES.length)];
}
