import Stripe from 'stripe';

let client: Stripe | null = null;

// Created on first use, so the app still starts before keys are added.
export function getStripe(): Stripe {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error('STRIPE_SECRET_KEY is not set. Add it to your .env file.');
  }
  client ??= new Stripe(process.env.STRIPE_SECRET_KEY);
  return client;
}
