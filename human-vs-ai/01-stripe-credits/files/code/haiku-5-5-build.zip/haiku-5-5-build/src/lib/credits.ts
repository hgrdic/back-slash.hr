import type Stripe from 'stripe';
import { db } from './db';
import { getPack } from './packs';

// Adds credits once per Stripe Checkout session. Safe to call from both the
// webhook and the success page, since the UNIQUE stripe_session_id stops double credits.
// Returns true if this call added the credits.
export function fulfillPaidSession(session: Stripe.Checkout.Session): boolean {
  if (session.payment_status !== 'paid') return false;

  // Sessions without our metadata come from other projects on the same Stripe account.
  const userId = Number(session.metadata?.userId);
  const pack = getPack(session.metadata?.packId ?? '');
  if (!userId || !pack) return false;

  if (session.amount_total !== pack.priceCents || session.currency !== 'usd') {
    throw new Error(`Checkout session ${session.id} amount does not match pack ${pack.id}`);
  }

  return db.transaction(() => {
    const inserted = db
      .prepare(
        `INSERT INTO purchases (stripe_session_id, user_id, pack_id, credits, amount_cents)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(stripe_session_id) DO NOTHING`,
      )
      .run(session.id, userId, pack.id, pack.credits, pack.priceCents);

    if (inserted.changes === 0) return false;

    db.prepare('UPDATE users SET credits = credits + ? WHERE id = ?').run(pack.credits, userId);
    return true;
  })();
}

// Returns the new balance, or null if the user has no credits left.
export function spendCredit(userId: number): number | null {
  const row = db
    .prepare('UPDATE users SET credits = credits - 1 WHERE id = ? AND credits >= 1 RETURNING credits')
    .get(userId) as { credits: number } | undefined;

  return row ? row.credits : null;
}
