// Credit packs are defined on the server only. The client sends a pack id,
// and the price and credit amount are looked up here.
export const PACKS = [
  { id: 'small', credits: 10, priceCents: 500, label: '10 credits' },
  { id: 'large', credits: 50, priceCents: 2000, label: '50 credits' },
] as const;

export type Pack = (typeof PACKS)[number];

export function getPack(id: string): Pack | undefined {
  return PACKS.find((pack) => pack.id === id);
}
