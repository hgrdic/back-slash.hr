# Motivation Credits

A small Next.js app. Users sign up, buy credits with Stripe Checkout, and spend 1 credit per click on "Generate" to get a random motivational quote. Data lives in a local SQLite file, so there is no database to set up.

- 10 credits for $5
- 50 credits for $20

## Start it

Requires Node 20.9 or newer.

```bash
npm install
```

Open `.env` and paste your Stripe **test** secret key from https://dashboard.stripe.com/test/apikeys:

```
STRIPE_SECRET_KEY=sk_test_...
```

Then start the app:

```bash
npm run dev
```

Go to http://localhost:3000, sign up, and buy credits. For a test payment, use the card `4242 4242 4242 4242` with any future expiry date, any CVC, and any ZIP code.

## Optional: webhook for local dev

The success page already adds credits after payment, so you can skip this step. The webhook is the main path, though, and covers cases where the browser closes before returning to the app. To use it, install the Stripe CLI (`brew install stripe/stripe-cli/stripe`), then in a second terminal run:

```bash
stripe login
stripe listen --forward-to localhost:3000/api/webhook
```

The `stripe listen` command prints a signing secret that starts with `whsec_`. Paste it into `STRIPE_WEBHOOK_SECRET` in `.env`, then restart `npm run dev`.

## Where things are

- `src/lib/packs.ts`: credit packs and prices. Prices are set on the server only.
- `src/lib/quotes.ts`: the list of quotes.
- `src/lib/credits.ts`: adds credits after payment (idempotent) and spends credits.
- `src/app/api/webhook/route.ts`: Stripe webhook.
- `src/app/api/generate/route.ts`: the Generate endpoint.
- `data/app.db`: the SQLite database. Delete it to reset everything.

## Notes

- Sessions are stored in the database and expire after 30 days.
- New accounts start with 0 credits.
- Keep your secret keys out of git. `.env` is already in `.gitignore`.
