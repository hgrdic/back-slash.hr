#!/bin/zsh
# Checks the episode 1 app (the Opus build by default) without a Stripe account.
#
#   episodes/01-stripe-credits/check.sh [opus | sonnet | haiku] [git commit]
#
# Without a commit it checks the app as it is now; for the AI build before any
# fix, pass its first commit (git log in the app folder).
#
# Starts the app on port 3101 with a local webhook secret and a fresh database,
# then: a forged event, a real looking purchase, a replay of it, three quotes
# spent, a full refund, a chargeback, and a chargeback after spending everything.
# Prints the credit balance after each.
set -uo pipefail

root=${0:A:h:h:h}
# Each build put its schema, database and webhook in a different place.
case ${1:-opus} in
  opus)   app=$root/apps/01-stripe-credits; schema=lib/db.ts; dbfile=app.db; hook=/api/webhooks/stripe ;;
  sonnet) app=$root/apps/01-stripe-credits-claude-sonnet-5-5; schema=lib/db.js; dbfile=data.db; hook=/api/webhook ;;
  haiku)  app=$root/apps/01-stripe-credits-claude-haiku-5-5; schema=src/lib/db.ts; dbfile=data/app.db; hook=/api/webhook ;;
  *) echo "usage: check.sh [opus | sonnet | haiku]"; exit 2 ;;
esac
port=3101
secret=whsec_local_check_only
url=http://localhost:$port$hook
send() { node "$root/tools/stripe-event.mjs" "$url" "$@"; }

cd "$app"
work=$(mktemp -d)
cp -R . "$work/app" 2>/dev/null
cd "$work/app"
[[ -n ${2:-} ]] && git checkout -q "$2"
rm -rf app.db*(N) data.db*(N) data; mkdir -p "$(dirname $dbfile)"

SESSION_SECRET=local_check_only_session_secret STRIPE_SECRET_KEY=sk_test_not_used STRIPE_WEBHOOK_SECRET=$secret APP_URL=http://localhost:$port \
  npx next dev -p $port > "$work/server.log" 2>&1 &
server=$!
trap 'kill $server 2>/dev/null; pkill -P $server 2>/dev/null; rm -rf "$work"' EXIT
until curl -s -o /dev/null http://localhost:$port/login; do sleep 1; done

sqlite=/usr/bin/sqlite3
# The app creates its tables on first use; create them from its own schema.
python3 -c 'import re,sys; print(re.search(r"db\.exec\(`(.*?)`", open(sys.argv[1]).read(), re.S).group(1))' $schema | $sqlite $dbfile
credits() { $sqlite $dbfile "SELECT credits FROM users WHERE id = 1"; }
echo "== new user"
$sqlite $dbfile "INSERT INTO users (email, password_hash) VALUES ('buyer@example.test', 'x')"
echo "credits: $(credits)"

echo "\n== 1. forged purchase, no signature"
send --unsigned checkout.session.completed object.id=cs_test_forged payment_status=paid amount_total=2000 currency=usd metadata.userId=1 metadata.packId=large
echo "== forged purchase, wrong signature"
send --bad-signature checkout.session.completed object.id=cs_test_forged payment_status=paid amount_total=2000 currency=usd metadata.userId=1 metadata.packId=large
echo "credits: $(credits)"

echo "\n== 2. real looking purchase of 50 credits for \$20"
pay=(object.id=cs_test_paid1 payment_status=paid amount_total=2000 currency=usd payment_intent=pi_test_1 metadata.userId=1 metadata.packId=large)
send $secret checkout.session.completed id=evt_test_purchase $pay
echo "credits: $(credits)"

echo "\n== 3. the same event replayed"
send $secret checkout.session.completed id=evt_test_purchase $pay
echo "credits: $(credits)"

echo "\n== 4. three quotes spent"
$sqlite $dbfile "UPDATE users SET credits = credits - 3 WHERE id = 1"
echo "credits: $(credits)"

echo "\n== 5. full refund of the \$20"
send $secret charge.refunded object.id=ch_test_1 object=charge payment_intent=pi_test_1 amount=2000 amount_refunded=2000 refunded=true currency=usd
echo "credits: $(credits)"

echo "\n== 6. chargeback (dispute) on the same payment"
send $secret charge.dispute.created object.id=dp_test_1 object=dispute charge=ch_test_1 payment_intent=pi_test_1 amount=2000 currency=usd reason=fraudulent status=needs_response
echo "credits: $(credits)"

echo "\n== 7. a second purchase, all 50 credits spent, then a chargeback"
pay2=(object.id=cs_test_paid2 payment_status=paid amount_total=2000 currency=usd payment_intent=pi_test_2 metadata.userId=1 metadata.packId=large)
send $secret checkout.session.completed $pay2
$sqlite $dbfile "UPDATE users SET credits = 0 WHERE id = 1"
echo "spent everything, credits: $(credits)"
send $secret charge.dispute.created object.id=dp_test_2 object=dispute charge=ch_test_2 payment_intent=pi_test_2 amount=2000 currency=usd reason=fraudulent status=needs_response
echo "credits: $(credits), payments on record: $($sqlite $dbfile 'SELECT COUNT(*) FROM '$($sqlite $dbfile "SELECT name FROM sqlite_master WHERE name IN ('payments','purchases')"))"
echo "nothing in the code locks or flags the account (checked by reading it), so it can log in and buy again"
