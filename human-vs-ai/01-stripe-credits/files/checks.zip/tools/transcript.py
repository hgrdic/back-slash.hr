"""Turns a Claude Code stream-json transcript into readable Markdown.

    python3 tools/transcript.py transcript.jsonl > transcript.md

Shows what the AI said and every tool call it made, in order, so the video
and the blog post can quote it exactly.
"""
import json
import sys


def short(text, limit=1500):
    text = text if isinstance(text, str) else json.dumps(text, indent=2)
    return text if len(text) <= limit else text[:limit] + f"\n... ({len(text) - limit} more characters)"


def main(path):
    for line in open(path):
        event = json.loads(line)
        kind = event.get("type")
        if kind == "system" and event.get("subtype") == "init":
            print(f"# AI build transcript\n\nModel: {event.get('model')}\n")
        elif kind == "assistant":
            for part in event["message"].get("content", []):
                if part.get("type") == "text" and part["text"].strip():
                    print(f"**AI:** {part['text'].strip()}\n")
                elif part.get("type") == "tool_use":
                    args = part.get("input", {})
                    if part["name"] == "Bash":
                        print(f"**Runs:** `{args.get('command')}`\n")
                    elif part["name"] in ("Write", "Edit"):
                        print(f"**{part['name']}:** `{args.get('file_path')}`\n")
                    else:
                        print(f"**{part['name']}:** `{short(args, 200)}`\n")
        elif kind == "user":
            for part in event["message"].get("content", []):
                if isinstance(part, dict) and part.get("type") == "tool_result" and part.get("is_error"):
                    content = part.get("content")
                    if isinstance(content, list):
                        content = " ".join(c.get("text", "") for c in content)
                    print(f"> Tool error: {short(content, 400)}\n")
        elif kind == "result":
            cost = event.get("total_cost_usd")
            print(f"---\n\nTurns: {event.get('num_turns')}, time: {round(event.get('duration_ms', 0) / 1000)} s"
                  + (f", cost: ${cost:.2f}" if cost else ""))
            if event.get("result"):
                print(f"\n**Final answer:**\n\n{event['result']}")


if __name__ == "__main__":
    main(sys.argv[1])
