#!/bin/zsh
# Runs one honest, unsteered AI build for an episode.
#
#   tools/ai-build.sh <episode> [model]
#
# Reads episodes/<episode>/prompt.md (the exact words a normal user would type),
# builds the app in a fresh, empty apps/<episode> with headless Claude Code, and
# saves the full transcript next to the prompt. With a model, the app goes to
# apps/<episode>-<model> and the transcript to ai-build-<model>, so several
# models can answer the same prompt; report every run, not only the worst.
# The result is committed as is, so the "AI built it" claim in the video can
# always be checked.
set -euo pipefail

root=${0:A:h:h}
ep=${1:?usage: ai-build.sh <episode> [model]}
model=${2:-}
prompt="$root/episodes/$ep/prompt.md"
suffix=${model:+-$model}
app="$root/apps/$ep$suffix"
out="$root/episodes/$ep/ai-build$suffix"

[[ -f $prompt ]] || { echo "missing $prompt"; exit 1; }
[[ -e $app ]] && { echo "$app already exists; move it away first, never reuse a build"; exit 1; }

mkdir -p "$app" "$out"
cd "$app"
git init -q

args=(-p "$(<$prompt)"
  --output-format stream-json --verbose
  --permission-mode acceptEdits
  --strict-mcp-config
  --no-session-persistence
  --allowedTools "Read" "Write" "Edit" "Glob" "Grep"
    "Bash(npm *)" "Bash(npx *)" "Bash(node *)" "Bash(mkdir *)" "Bash(ls *)" "Bash(cat *)")
[[ -n $model ]] && args+=(--model "$model")

started=$(date -u +%Y-%m-%dT%H:%M:%SZ)
CLAUDE_CONFIG_DIR=~/.claude-personal1 /opt/homebrew/bin/claude "${args[@]}" < /dev/null > "$out/transcript.jsonl"

python3 "$root/tools/transcript.py" "$out/transcript.jsonl" > "$out/transcript.md"
cp "$prompt" "$out/prompt.md"
{
  echo "started: $started"
  echo "finished: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "tool: Claude Code $(/opt/homebrew/bin/claude --version | head -1)"
  echo "model: $(python3 -c 'import json,sys
for l in open(sys.argv[1]):
    e=json.loads(l)
    if e.get("type")=="system" and e.get("model"): print(e["model"]); break' "$out/transcript.jsonl")"
} > "$out/run.txt"

# Never edit the AI's files (its .gitignore included); keep secrets and
# build output out of the commit through git's local exclude list instead.
printf '%s\n' node_modules/ .next/ '.env' '.env.local' '*.db' '*.db-*' '*.sqlite' >> .git/info/exclude
git add -A
git -c user.name="AI build" -c user.email="ai-build@localhost" commit -qm "AI build from the episode prompt, unedited"
echo "built $app; transcript in $out"
