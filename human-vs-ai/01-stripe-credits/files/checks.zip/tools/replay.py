"""Replays a saved AI build in the terminal, at a pace that suits screen recording.

    python3 tools/replay.py episodes/<episode>/ai-build/transcript.jsonl [--speed 1.0]

It prints the real transcript (the prompt, what the AI said, each command and
file it wrote) with typing and pauses. Nothing is regenerated, so what's shown
is exactly what the AI did. Say on camera that it's a sped up replay.
"""
import argparse
import json
import os
import sys
import time

DIM, BOLD, CYAN, GREEN, RESET = "\033[2m", "\033[1m", "\033[36m", "\033[32m", "\033[0m"


def type_out(text, cps, speed):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(1 / (cps * speed))
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("transcript")
    ap.add_argument("--speed", type=float, default=1.0)
    args = ap.parse_args()
    pause = lambda s: time.sleep(s / args.speed)
    events = [json.loads(line) for line in open(args.transcript)]
    prompt = open(os.path.join(os.path.dirname(args.transcript), "prompt.md")).read().strip()

    os.system("clear")
    sys.stdout.write(f"{BOLD}> {RESET}")
    type_out(prompt, 40, args.speed)
    pause(1.5)

    for event in events:
        if event.get("type") != "assistant":
            continue
        for part in event["message"].get("content", []):
            if part.get("type") == "text" and part["text"].strip():
                print()
                type_out(part["text"].strip(), 220, args.speed)
                pause(0.6)
            elif part.get("type") == "tool_use":
                inp = part.get("input", {})
                if part["name"] == "Bash":
                    print(f"{CYAN}  $ {inp.get('command')}{RESET}")
                elif part["name"] == "Write":
                    path = inp.get("file_path", "")
                    lines = (inp.get("content") or "").count("\n") + 1
                    print(f"{GREEN}  wrote {os.path.basename(path)}{RESET} {DIM}({lines} lines){RESET}")
                elif part["name"] == "Edit":
                    print(f"{GREEN}  edited {os.path.basename(inp.get('file_path', ''))}{RESET}")
                else:
                    continue
                pause(0.35)
    print(f"\n{DIM}(replay of the saved run){RESET}")


if __name__ == "__main__":
    main()
