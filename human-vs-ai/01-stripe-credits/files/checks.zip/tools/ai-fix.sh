#!/bin/zsh
# Asks the AI to fix a finding, the way a founder would, and keeps the result.
#
#   tools/ai-fix.sh <episode> <fix name> [app folder name] [model]
#
# Reads episodes/<episode>/fix-<fix name>.md (a plain prompt describing the
# problem, no hints about the solution), runs headless Claude Code in the
# app's existing repo, saves the transcript to episodes/<episode>/ai-fix-<fix name>/
# and commits the AI's changes unedited, so the video can show the real diff.
set -euo pipefail

root=${0:A:h:h}
ep=${1:?usage: ai-fix.sh <episode> <fix name> [app folder name] [model]}
name=${2:?fix name}
app="$root/apps/${3:-$ep}"
model=${4:-}
prompt="$root/episodes/$ep/fix-$name.md"
out="$root/episodes/$ep/ai-fix-$name${model:+-$model}"

[[ -f $prompt ]] || { echo "missing $prompt"; exit 1; }
[[ -d $app/.git ]] || { echo "no app repo at $app"; exit 1; }
[[ -z $(git -C "$app" status --porcelain) ]] || { echo "$app has uncommitted changes"; exit 1; }

mkdir -p "$out"
cd "$app"
args=(-p "$(<$prompt)"
  --output-format stream-json --verbose
  --permission-mode acceptEdits
  --strict-mcp-config
  --no-session-persistence
  --allowedTools "Read" "Write" "Edit" "Glob" "Grep"
    "Bash(npm *)" "Bash(npx *)" "Bash(node *)" "Bash(ls *)" "Bash(cat *)")
[[ -n $model ]] && args+=(--model "$model")

started=$(date -u +%Y-%m-%dT%H:%M:%SZ)
CLAUDE_CONFIG_DIR=~/.claude-personal1 /opt/homebrew/bin/claude "${args[@]}" < /dev/null > "$out/transcript.jsonl"
python3 "$root/tools/transcript.py" "$out/transcript.jsonl" > "$out/transcript.md"
cp "$prompt" "$out/prompt.md"
{
  echo "started: $started"
  echo "finished: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "app: $app"
  echo "tool: Claude Code $(/opt/homebrew/bin/claude --version | head -1)"
  echo "model: $(python3 -c 'import json,sys
for l in open(sys.argv[1]):
    e=json.loads(l)
    if e.get("type")=="system" and e.get("model"): print(e["model"]); break' "$out/transcript.jsonl")"
} > "$out/run.txt"

git add -A
git -c user.name="AI fix" -c user.email="ai-fix@localhost" commit -qm "AI fix for '$name' from the episode prompt, unedited"
echo "fixed in $app; transcript in $out"
