// Sends a Stripe style webhook event to a local app, signed or forged.
//
//   node tools/stripe-event.mjs <url> <whsec_secret | --unsigned | --bad-signature> <event type> [key=value ...]
//
// key=value pairs go into data.object (dots make nested keys, numbers stay
// numbers): metadata.userId=1 amount_total=2000. id=... sets the event id, so
// the same event can be replayed. Signing follows Stripe's scheme:
// header "t=<unix time>,v1=<HMAC SHA256 of '<t>.<body>' with the secret>".
// Only for the owner's own throwaway apps on localhost.
import crypto from "node:crypto";

const [url, secret, type, ...pairs] = process.argv.slice(2);
if (!url || !secret || !type) {
  console.error("usage: stripe-event.mjs <url> <whsec_... | --unsigned | --bad-signature> <type> [key=value ...]");
  process.exit(2);
}

const object = {};
let eventId = `evt_test_${crypto.randomBytes(8).toString("hex")}`;
for (const pair of pairs) {
  const at = pair.indexOf("=");
  const key = pair.slice(0, at);
  const raw = pair.slice(at + 1);
  const value = /^-?\d+$/.test(raw) ? Number(raw) : raw === "true" ? true : raw === "false" ? false : raw;
  if (key === "id" && !pair.startsWith("object.")) { eventId = raw; continue; }
  const path = key.replace(/^object\./, "").split(".");
  let node = object;
  for (const part of path.slice(0, -1)) node = node[part] ??= {};
  node[path.at(-1)] = value;
}

const body = JSON.stringify({
  id: eventId,
  object: "event",
  api_version: "2025-01-27.acacia",
  created: Math.floor(Date.now() / 1000),
  livemode: false,
  type,
  data: { object },
});

const headers = { "content-type": "application/json" };
if (secret !== "--unsigned") {
  const t = Math.floor(Date.now() / 1000);
  const key = secret === "--bad-signature" ? "whsec_wrong" : secret;
  const v1 = crypto.createHmac("sha256", key).update(`${t}.${body}`).digest("hex");
  headers["stripe-signature"] = `t=${t},v1=${v1}`;
}

const res = await fetch(url, { method: "POST", headers, body });
console.log(`${type} (${secret.startsWith("--") ? secret.slice(2) : "signed"}) -> ${res.status} ${(await res.text()).slice(0, 120)}`);
